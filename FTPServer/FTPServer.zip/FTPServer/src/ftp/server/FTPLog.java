package ftp.server;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;


public class FTPLog{
    public void connection(String request, FTPUser userClient){
        if(request.equals("connect")){
            System.out.println(getTimestamp() + userInfo(userClient) + " conectou com êxito.");
        }else
        if (request.equals("close")){
            System.out.println(getTimestamp() + userInfo(userClient) + " desconectado com sucesso!");
        }
    }

    // See why it is not working srvStart
    public void srvStart(int port){
            System.out.println(getTimestamp() + " FTP Server iniciou na porta " + port);
    }
   //
    public void authenticateUser(FTPUser userClient){
        System.out.println(getTimestamp() + userInfo(userClient) + " autenticado com sucesso!");
    }
    
    public String getTimestamp(){
        DateFormat dateFormat = new SimpleDateFormat("'['hh:mm:ss']' ");  
        Date date = new Date();
        return dateFormat.format(date);
    }
    
    private String userInfo(FTPUser userClient){
        return userClient.getUsername() + "@" + userClient.getIPAddress().getHostAddress();
    }
    
    public void commandInitial(String command){
        switch (command) {
            case "STOR":
                    System.out.println(getTimestamp() + "Comando STOR recebido.");
                    System.out.println(getTimestamp() + "Esperando pelo nome do arquivo...");
                break;
            case "RETR":
                
                break;
            case "LIST":
                
                break;
            case "DISCONNECT":
                
                break;
            default:
                System.out.println("Comando não reconhecido!");
        }
    }
    
    public void commandReplies(String command){
        switch (command) {
            case "CANCEL":
                System.out.println(getTimestamp() + "Operação cancelada pelo cliente");
            break;
            case "SUCCESS":
                System.out.println(getTimestamp() + "Arquivo recebido com sucesso!");
            break;
            case "STORERROR":
                System.err.println(getTimestamp() + "Erro ao executar commando STOR!");
            default:
                break;
        }
    }
}
